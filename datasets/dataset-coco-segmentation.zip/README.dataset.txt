# project-luka-detection > 2025-10-16 2:37pm
https://universe.roboflow.com/atom-u9bu1/project-luka-detection-vcs3j

Provided by a Roboflow user
License: CC BY 4.0

