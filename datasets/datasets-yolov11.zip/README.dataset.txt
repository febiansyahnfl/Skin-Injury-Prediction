# wounds-detection > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/atom-u9bu1/wounds-detection-is4sm

Provided by a Roboflow user
License: CC BY 4.0

